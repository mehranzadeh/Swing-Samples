
public interface StringListener {
 public void setTextEmitted(String text);
 public void setTextClear();
}
